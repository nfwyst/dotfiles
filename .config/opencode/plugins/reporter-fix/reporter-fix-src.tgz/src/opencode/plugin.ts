import type { Plugin } from '@opencode-ai/plugin';
import { readOptionalTextFile } from '../shared/file.ts';
import { createDebugLogger, type DebugLogger } from '../shared/debug.ts';
import { type GitContext } from '../shared/git.ts';
import { logError } from '../shared/log.ts';
import { formatQualifiedModel } from '../shared/model.ts';
import { resolveAbsolutePath } from '../shared/path.ts';
import { TelemetryReporter, type TelemetryRecord } from '../shared/reporter.ts';
import { loadEnabledReporterConfig, resolveGitContextOrEmpty } from '../shared/runtime.ts';
import { extractToolChanges, extractAcceptedLines, type PendingWrite } from './extract.ts';
import { buildTelemetryRecords, TELEMETRY_SOURCE } from './telemetry.ts';
import { isRecord } from '../shared/value.ts';
import type {
  ChatMessageInput,
  ChatMessageOutput,
  ChatParamsInput,
  ChatParamsOutput,
  PluginEvent,
  PluginEventInput,
  ToolExecuteAfterInput,
  ToolExecuteAfterHookInput,
  ToolExecuteAfterOutput,
  ToolExecuteBeforeInput,
  ToolExecuteBeforeOutput,
} from './types.ts';

const CODE_TOOLS: Set<string> = new Set(['write', 'edit', 'apply_patch', 'multiedit']);
// Tools whose args contain a `filePath` we can snapshot before execution.
// `apply_patch` does not have a single filePath in args (multiple files in
// patch body), so it is intentionally excluded here.
const TOOLS_WITH_BEFORE_SNAPSHOT: Set<string> = new Set(['write', 'edit', 'multiedit']);
const MAX_CACHE_SIZE = 500;
const TEXT_EXTS = new Set(['.ts', '.tsx', '.js', '.jsx', '.mjs', '.cjs', '.py', '.go', '.rs', '.java', '.kt', '.swift', '.vue', '.svelte', '.css', '.scss', '.less', '.html', '.json', '.yaml', '.yml', '.toml', '.md', '.sql']);

type RuntimePluginEvent =
  | PluginEvent
  | { type: 'vcs.branch.updated'; properties: { branch?: string } }
  | { type: 'file.edited'; properties: { file: string } }
  | { type: 'file.watcher.updated'; properties: { file: string; event: string } };

function pendingWriteKey(sessionId: string, callId: string): string {
  return `${sessionId}:${callId}`;
}

function resolveFilePath(directory: string, filePath: string): string {
  return resolveAbsolutePath(directory, filePath);
}

async function readExistingFile(filePath: string): Promise<string> {
  return (await readOptionalTextFile(filePath)) ?? '';
}

export const ReporterPlugin: Plugin = async ({ directory, worktree }) => {
  const config = await loadEnabledReporterConfig();
  if (!config) {
    return {};
  }

  const debugLogger: DebugLogger = createDebugLogger(config, TELEMETRY_SOURCE, worktree);
  debugLogger.log('opencode.plugin.config.loaded', {
    enabled: config.enabled,
    endpoint: config.endpoint,
    debug: config.debug,
  });
  debugLogger.log('opencode.plugin.init', { directory, worktree });

  const reporter: TelemetryReporter = new TelemetryReporter(config, undefined, debugLogger);
  const pendingWrites: Map<string, PendingWrite> = new Map();
  const sessionModels: Map<string, string> = new Map();
  const sessionBaseUrls: Map<string, string> = new Map();
  let lastModel: string | undefined;
  let lastBaseUrl: string | undefined;
  const fileCache: Map<string, string> = new Map();
  const cacheLock: Map<string, Promise<void>> = new Map();
  const reportedFiles: Set<string> = new Set();
  const newFiles: Set<string> = new Set();
  const gitContext: GitContext = await resolveGitContextOrEmpty(worktree, debugLogger);

  return {
    async event(input: PluginEventInput) {
      const evt = input.event as RuntimePluginEvent;

      if (evt.type === 'vcs.branch.updated') {
        if (typeof evt.properties.branch === 'string') {
          gitContext.branch = evt.properties.branch;
          debugLogger.log('opencode.branch.updated', { branch: gitContext.branch });
        }
        return;
      }

      if (evt.type === 'file.watcher.updated') {
        const fp = evt.properties.file;
        if (evt.properties.event === 'add') {
          newFiles.add(fp);
        } else if (evt.properties.event === 'unlink') {
          newFiles.delete(fp);
          fileCache.delete(fp);
        }
        return;
      }

      if (evt.type === 'file.edited') {
        const filePath = evt.properties.file;
        debugLogger.log('opencode.event.file.edited.enter', { filePath, ext: filePath.slice(filePath.lastIndexOf('.')), ignored: config.ignorePath.some((f) => filePath.includes(f)), reported: reportedFiles.has(filePath) });
        if (!filePath || config.ignorePath.some((f) => filePath.includes(f))) return;
        if (reportedFiles.has(filePath)) { debugLogger.log('opencode.event.file.edited.dedup', { filePath }); return; }

        const ext = filePath.slice(filePath.lastIndexOf('.'));
        if (!TEXT_EXTS.has(ext)) return;

        const model = lastModel;
        const baseUrl = lastBaseUrl;

        const prev = cacheLock.get(filePath) ?? Promise.resolve();
        const done = prev.then(async () => {
          const after = await readExistingFile(filePath).catch((err) => {
            debugLogger.log('opencode.event.file.edited.read.error', { filePath, error: String(err) });
            return '';
          });
          if (after.length === 0) return;

          const before = fileCache.get(filePath) ?? '';
          const cacheHit = before !== '';
          fileCache.set(filePath, after);
          if (fileCache.size > MAX_CACHE_SIZE) {
            fileCache.delete(fileCache.keys().next().value!);
          }
          newFiles.delete(filePath);

          const lines = extractAcceptedLines(before, after);
          debugLogger.log('opencode.event.file.edited.diff', { filePath, cacheHit, beforeLen: before.length, afterLen: after.length, lineCount: lines.length, cacheSize: fileCache.size });
          if (lines.length === 0) return;

          const records = buildTelemetryRecords({
            changes: [{ filePath, lines }],
            gitContext,
            sessionId: '__file__',
            toolName: 'file.edited',
            callId: `file:${filePath}`,
            maxContentLength: config.maxContentLength,
            ignorePath: [],
            model,
            baseUrl,
          });

          debugLogger.log('opencode.event.file.edited.records', { filePath, recordCount: records.length });
          if (records.length > 0) reporter.enqueue(records);
        }).finally(() => {
          cacheLock.delete(filePath);
        });

        cacheLock.set(filePath, done);
        await done;
        return;
      }

    },
    async 'chat.message'(input: ChatMessageInput, _output: ChatMessageOutput) {
      const model: string | undefined = input.model
        ? formatQualifiedModel(input.model.providerID, input.model.modelID)
        : undefined;

      if (model) {
        sessionModels.set(input.sessionID, model);
        lastModel = model;
        debugLogger.log('opencode.chat.message.model', {
          sessionId: input.sessionID,
          model,
        });
      }
    },
    async 'chat.params'(input: ChatParamsInput, _output: ChatParamsOutput) {
      const model: string | undefined = formatQualifiedModel(input.provider.id, input.model.id);

      if (model) {
        sessionModels.set(input.sessionID, model);
        lastModel = model;
        debugLogger.log('opencode.chat.params.model', {
          sessionId: input.sessionID,
          model,
        });
      }

      const provider = input.provider;
      const api = isRecord(provider) && typeof provider.api === 'string' ? provider.api : '';
      if (api.length > 0) {
        sessionBaseUrls.set(input.sessionID, api);
        lastBaseUrl = api;
        debugLogger.log('opencode.chat.params.base-url', {
          sessionId: input.sessionID,
          baseUrl: api,
        });
      }
    },
    async 'tool.execute.before'(input: ToolExecuteBeforeInput, output: ToolExecuteBeforeOutput) {
      if (!config.enabled || !TOOLS_WITH_BEFORE_SNAPSHOT.has(input.tool)) {
        return;
      }

      const args: Record<string, unknown> | undefined =
        typeof output.args === 'object' && output.args !== null && !Array.isArray(output.args)
          ? (output.args as Record<string, unknown>)
          : undefined;

      const filePathArg: unknown = args?.filePath;
      if (typeof filePathArg !== 'string' || filePathArg.length === 0) {
        return;
      }

      const filePath: string = resolveFilePath(directory, filePathArg);
      debugLogger.log('opencode.tool.before.snapshot', {
        sessionId: input.sessionID,
        callId: input.callID,
        toolName: input.tool,
        filePath,
      });

      const before: string = await readExistingFile(filePath).catch((error) => {
        const message: string = error instanceof Error ? error.message : String(error);
        logError(`写入前读取文件失败: ${message}`);
        debugLogger.log('opencode.tool.before.snapshot.error', {
          toolName: input.tool,
          filePath,
          message,
        });
        return '';
      });

      pendingWrites.set(pendingWriteKey(input.sessionID, input.callID), {
        filePath,
        before,
        ts: Date.now(),
      });
      debugLogger.log('opencode.tool.before.snapshot.cached', {
        sessionId: input.sessionID,
        callId: input.callID,
        toolName: input.tool,
        filePath,
        beforeLength: before.length,
      });
    },
    async 'tool.execute.after'(input: ToolExecuteAfterHookInput, output: ToolExecuteAfterOutput) {
      if (!config.enabled || !CODE_TOOLS.has(input.tool)) {
        return;
      }

      debugLogger.log('opencode.tool.after.start', {
        sessionId: input.sessionID,
        callId: input.callID,
        toolName: input.tool,
      });

      const runtimeInput: ToolExecuteAfterInput = input as ToolExecuteAfterInput;
      const cacheKey: string = pendingWriteKey(input.sessionID, input.callID);
      const pendingWrite: PendingWrite | undefined = pendingWrites.get(cacheKey);

      // For tools whose post-image is not in metadata (edit/multiedit on
      // opencode >= 1.15), read the on-disk content as a robust fallback.
      let afterContent: string | undefined;
      if (pendingWrite?.filePath) {
        afterContent = await readExistingFile(pendingWrite.filePath).catch((error) => {
          const message: string = error instanceof Error ? error.message : String(error);
          debugLogger.log('opencode.tool.after.read.error', {
            toolName: input.tool,
            filePath: pendingWrite.filePath,
            message,
          });
          return undefined;
        });
        debugLogger.log('opencode.tool.after.read', {
          toolName: input.tool,
          filePath: pendingWrite.filePath,
          beforeLength: pendingWrite.before.length,
          afterLength: afterContent?.length ?? -1,
        });
      }

      const changes = extractToolChanges({
        tool: input.tool,
        args: runtimeInput.args,
        metadata: output.metadata,
        directory,
        pendingWrite,
        afterContent,
      });

      debugLogger.log('opencode.tool.after.changes', {
        toolName: input.tool,
        changeCount: changes.length,
        usedFallback: changes.length > 0 && afterContent !== undefined,
      });

      pendingWrites.delete(cacheKey);

      for (const change of changes) {
        reportedFiles.add(change.filePath);
        // Seed the file.edited cache so the event fallback does not double
        // report the same lines after we've already accounted for them here.
        if (afterContent !== undefined) {
          fileCache.set(change.filePath, afterContent);
        }
        setTimeout(() => reportedFiles.delete(change.filePath), 5000);
      }

      for (const [key, pw] of pendingWrites) {
        if (pw.ts && Date.now() - pw.ts > 30000) {
          pendingWrites.delete(key);
        }
      }

      const model: string | undefined = sessionModels.get(input.sessionID);
      const baseUrl: string | undefined = sessionBaseUrls.get(input.sessionID);

      const records: TelemetryRecord[] = buildTelemetryRecords({
        changes,
        gitContext,
        sessionId: input.sessionID,
        toolName: input.tool,
        callId: input.callID,
        maxContentLength: config.maxContentLength,
        ignorePath: config.ignorePath,
        model,
        baseUrl,
      });

      debugLogger.log('opencode.tool.after.records', {
        toolName: input.tool,
        recordCount: records.length,
      });

      reporter.enqueue(records);
    },
  };
};

export default ReporterPlugin;
