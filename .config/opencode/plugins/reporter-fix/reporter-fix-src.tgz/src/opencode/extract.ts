import {
  buildAcceptedChange,
  coalesceAcceptedChanges,
  extractAcceptedLines,
  extractAddedLinesFromUnifiedPatch,
  type AcceptedChange,
} from '../shared/change.ts';
import { resolveAbsolutePath } from '../shared/path.ts';
import { isRecord, readString } from '../shared/value.ts';

export { extractAcceptedLines } from '../shared/change.ts';

export interface PendingWrite {
  filePath: string;
  before: string;
  ts?: number;
}

export interface ExtractToolChangeInput {
  tool: string;
  args: unknown;
  metadata: unknown;
  directory: string;
  pendingWrite?: PendingWrite;
  /**
   * Fresh on-disk content read just after the tool finished. Used as a
   * fallback when the SDK metadata schema does not expose the post-image
   * (which is the case for opencode >= 1.15 `edit` / `multiedit`).
   */
  afterContent?: string;
}

interface FileDiffLike {
  file?: unknown;
  before?: unknown;
  after?: unknown;
}

interface ApplyPatchFileLike {
  filePath?: unknown;
  movePath?: unknown;
  patch?: unknown;
  type?: unknown;
}

interface MultiEditResultLike {
  filediff?: FileDiffLike;
}

function resolveFilePath(directory: string, filePath: string): string {
  return resolveAbsolutePath(directory, filePath);
}

function fromFileDiff(fileDiff: FileDiffLike): AcceptedChange[] {
  const filePath: string | undefined = readString(fileDiff.file);
  const before: string | undefined = readString(fileDiff.before);
  const after: string | undefined = readString(fileDiff.after);

  if (!filePath || before === undefined || after === undefined) {
    return [];
  }

  return [
    {
      filePath,
      lines: extractAcceptedLines(before, after),
    },
  ];
}

function readArgsFilePath(input: ExtractToolChangeInput): string | undefined {
  const args: Record<string, unknown> | undefined = isRecord(input.args) ? input.args : undefined;
  const argsPath: string | undefined = readString(args?.filePath);
  return argsPath ? resolveFilePath(input.directory, argsPath) : undefined;
}

function readMetadataFilePath(input: ExtractToolChangeInput): string | undefined {
  const metadata: Record<string, unknown> | undefined = isRecord(input.metadata)
    ? input.metadata
    : undefined;
  const raw: string | undefined = readString(metadata?.filepath) ?? readString(metadata?.filePath);
  if (!raw) return undefined;
  return resolveFilePath(input.directory, raw);
}

/**
 * Last-resort fallback: produce an AcceptedChange from `pendingWrite.before`
 * and the freshly read on-disk `afterContent`. Returns [] if either side is
 * missing or the file path cannot be determined.
 */
function fallbackFromPendingAndDisk(input: ExtractToolChangeInput): AcceptedChange[] {
  const pending = input.pendingWrite;
  const after = input.afterContent;
  if (after === undefined) return [];

  const filePath: string | undefined =
    pending?.filePath ?? readMetadataFilePath(input) ?? readArgsFilePath(input);
  if (!filePath) return [];

  const before: string = pending?.before ?? '';
  const lines = extractAcceptedLines(before, after);
  if (lines.length === 0) return [];

  return [{ filePath, lines }];
}

function extractWriteChanges(input: ExtractToolChangeInput): AcceptedChange[] {
  const args: Record<string, unknown> | undefined = isRecord(input.args) ? input.args : undefined;
  const metadata: Record<string, unknown> | undefined = isRecord(input.metadata)
    ? input.metadata
    : undefined;
  const after: string | undefined = readString(args?.content) ?? input.afterContent;
  const metadataPath: string | undefined = readString(metadata?.filepath);
  const argsPath: string | undefined = readString(args?.filePath);
  const filePath: string | undefined =
    metadataPath ?? (argsPath ? resolveFilePath(input.directory, argsPath) : undefined);

  if (!filePath || after === undefined) {
    return [];
  }

  return [
    {
      filePath,
      lines: extractAcceptedLines(input.pendingWrite?.before ?? '', after),
    },
  ];
}

function extractEditChanges(input: ExtractToolChangeInput): AcceptedChange[] {
  // Preferred path: metadata.filediff (legacy schema).
  if (isRecord(input.metadata) && isRecord(input.metadata.filediff)) {
    const direct = fromFileDiff(input.metadata.filediff);
    if (direct.length > 0) return direct;
  }
  // Fallback path: opencode >= 1.15 no longer exposes filediff in metadata,
  // reconstruct from pendingWrite.before + on-disk after.
  return fallbackFromPendingAndDisk(input);
}

function extractApplyPatchChanges(input: ExtractToolChangeInput): AcceptedChange[] {
  const metadata = input.metadata;
  if (isRecord(metadata) && Array.isArray(metadata.files)) {
    const fromMetadata = coalesceAcceptedChanges(
      metadata.files.flatMap((item: unknown) => {
        if (!isRecord(item)) return [];

        const patchFile: ApplyPatchFileLike = item;
        if (patchFile.type === 'delete') return [];

        const filePath: string | undefined =
          readString(patchFile.movePath) ?? readString(patchFile.filePath);
        const patch: string | undefined = readString(patchFile.patch);

        if (!filePath || patch === undefined) return [];

        return buildAcceptedChange(filePath, extractAddedLinesFromUnifiedPatch(patch));
      })
    );
    if (fromMetadata.length > 0) return fromMetadata;
  }
  return fallbackFromPendingAndDisk(input);
}

function extractMultiEditChanges(input: ExtractToolChangeInput): AcceptedChange[] {
  const metadata = input.metadata;
  if (isRecord(metadata) && Array.isArray(metadata.results)) {
    const grouped: Map<string, { before: string; after: string }> = new Map();

    for (const item of metadata.results) {
      if (!isRecord(item) || !isRecord(item.filediff)) continue;

      const result: MultiEditResultLike = item;
      const filePath: string | undefined = readString(result.filediff?.file);
      const before: string | undefined = readString(result.filediff?.before);
      const after: string | undefined = readString(result.filediff?.after);

      if (!filePath || before === undefined || after === undefined) continue;

      const existing = grouped.get(filePath);
      if (!existing) {
        grouped.set(filePath, { before, after });
        continue;
      }

      grouped.set(filePath, { before: existing.before, after });
    }

    if (grouped.size > 0) {
      return Array.from(grouped.entries(), ([filePath, change]) => ({
        filePath,
        lines: extractAcceptedLines(change.before, change.after),
      }));
    }
  }
  return fallbackFromPendingAndDisk(input);
}

export function extractToolChanges(input: ExtractToolChangeInput): AcceptedChange[] {
  switch (input.tool) {
    case 'write':
      return extractWriteChanges(input);
    case 'edit':
      return extractEditChanges(input);
    case 'apply_patch':
      return extractApplyPatchChanges(input);
    case 'multiedit':
      return extractMultiEditChanges(input);
    default:
      return [];
  }
}
