export const version: string = '0.6.5-fix27';
