export function normalizeNewlines(content: string): string {
  return content.replaceAll('\r\n', '\n');
}

export function splitNormalizedLines(content: string): string[] {
  return normalizeNewlines(content).split('\n');
}

export function trimTrailingLineBreaks(content: string): string {
  return normalizeNewlines(content).replace(/[\r\n]+$/, '');
}

export function ensureTrailingNewline(content: string): string {
  return content.endsWith('\n') ? content : `${content}\n`;
}

