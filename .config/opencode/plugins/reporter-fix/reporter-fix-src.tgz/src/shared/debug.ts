import os from 'os';
import path from 'path';
import { version } from '../version.ts';
import type { ReporterConfig } from './config.ts';
import { appendTextFile } from './file.ts';
import { logError } from './log.ts';

export interface DebugLogger {
  readonly enabled: boolean;
  log(step: string, data?: Record<string, unknown>): void;
  flush(): Promise<void>;
}

interface DebugEntry {
  timestamp: string;
  worktree: string;
  plugin_version: string;
  step: string;
  data?: Record<string, unknown>;
}

class NoopDebugLogger implements DebugLogger {
  readonly enabled: boolean = false;

  log(_step: string, _data?: Record<string, unknown>): void {}

  async flush(): Promise<void> {}
}

class JsonlDebugLogger implements DebugLogger {
  readonly enabled: boolean = true;
  private readonly worktree: string;
  private readonly filePath: string;
  private pendingWrite: Promise<void> = Promise.resolve();
  private pendingCount = 0;

  constructor(worktree: string, filePath: string) {
    this.worktree = worktree;
    this.filePath = filePath;
  }

  log(step: string, data?: Record<string, unknown>): void {
    const entry: DebugEntry = {
      timestamp: new Date().toISOString(),
      worktree: this.worktree,
      plugin_version: version,
      step,
      ...(data ? { data } : {}),
    };

    this.pendingCount++;
    if (this.pendingCount > 256) {
      this.pendingWrite = Promise.resolve();
      this.pendingCount = 0;
    }

    this.pendingWrite = this.pendingWrite
      .then(() => appendTextFile(this.filePath, JSON.stringify(entry) + '\n'));

    this.pendingWrite.catch((error) => {
      const message: string = error instanceof Error ? error.message : String(error);
      logError(`写入 debug 日志失败: ${message}`);
    });
  }

  async flush(): Promise<void> {
    await this.pendingWrite.catch(() => undefined);
  }
}

const NOOP_DEBUG_LOGGER: DebugLogger = new NoopDebugLogger();

function padTimeSegment(value: number): string {
  return String(value).padStart(2, '0');
}

export function formatDebugLogHour(date: Date): string {
  const year: number = date.getFullYear();
  const month: string = padTimeSegment(date.getMonth() + 1);
  const day: string = padTimeSegment(date.getDate());
  const hour: string = padTimeSegment(date.getHours());

  return `${year}_${month}_${day}_${hour}00`;
}

export function createDebugLogFilePath(
  source: string,
  homeDirectory: string = os.homedir(),
  now: number = Date.now()
): string {
  const fileName: string = `${source}-${formatDebugLogHour(new Date(now))}.jsonl`;

  return path.join(homeDirectory, 'Library', 'Logs', 'opencode-reporter-plugin', fileName);
}

export function createDebugLogger(
  config: ReporterConfig,
  source: string,
  worktree: string
): DebugLogger {
  if (!config.debug) {
    return NOOP_DEBUG_LOGGER;
  }

  return new JsonlDebugLogger(worktree, createDebugLogFilePath(source));
}

