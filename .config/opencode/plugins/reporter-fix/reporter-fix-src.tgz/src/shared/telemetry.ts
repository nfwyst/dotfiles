import { createHash } from 'node:crypto';

import type { GitContext } from './git.ts';
import type { TelemetryRecord } from './reporter.ts';
import type { AcceptedChange } from './change.ts';
import { version } from '../version.ts';

export type { AcceptedChange } from './change.ts';
// import { writeFile } from 'fs/promises';

export interface BuildTelemetryRecordsInput {
  changes: AcceptedChange[];
  gitContext: GitContext;
  sessionId: string;
  toolName: string;
  callId: string;
  maxContentLength: number;
  ignorePath: string[];
  source: string;
  model?: string;
  baseUrl?: string;
}

export type BuildTelemetryRecordsWithSourceInput = Omit<BuildTelemetryRecordsInput, 'source'>;
export type BuildTelemetryRecordsWithDefaultsInput = Omit<
  BuildTelemetryRecordsInput,
  'source' | 'toolName'
>;

function clampContent(content: string, maxContentLength: number): string {
  if (content.length <= maxContentLength) {
    return content;
  }

  return content.slice(0, maxContentLength);
}

function hasRequiredGitContext(gitContext: GitContext): boolean {
  return gitContext.username.trim().length > 0 && gitContext.gitUrl.trim().length > 0;
}

function isGitHubUrl(gitUrl: string): boolean {
  const stripped = gitUrl.trim().toLowerCase()
    .replace(/^https:\/\/[^@]+@/, 'https://');
  return stripped.startsWith('https://github.com/') || stripped.startsWith('git@github.com:');
}

export interface TelemetrySignInput {
  createdAt: number;
  username: string;
  filePath: string;
  callId: string;
  source: string;
  lineContent: string;
}

export function buildTelemetrySign(input: TelemetrySignInput): string {
  const content = input.lineContent.slice(0, 100);
  const raw = `${input.createdAt}${input.username}${input.filePath}${input.callId}${input.source}${content}${version}PANPAN`;
  return createHash('sha1').update(raw).digest('hex');
}

export function verifyTelemetrySign(
  record: Pick<
    TelemetryRecord,
    'created_at' | 'username' | 'file_path' | 'call_id' | 'source' | 'accept_content' | 'sign'
  >
): boolean {
  return (
    buildTelemetrySign({
      createdAt: record.created_at,
      username: record.username,
      filePath: record.file_path,
      callId: record.call_id,
      source: record.source,
      lineContent: record.accept_content,
    }) === record.sign
  );
}

export function buildTelemetryRecords(input: BuildTelemetryRecordsInput): TelemetryRecord[] {
  // writeFile(`/Users/bytedance/Desktop/build-${Date.now()}.json`, JSON.stringify(input, null, 2));
  if (!hasRequiredGitContext(input.gitContext)) {
    return [];
  }

  if (isGitHubUrl(input.gitContext.gitUrl)) {
    return [];
  }

  const createdAt: number = Math.floor(Date.now() / 1000);

  return input.changes.flatMap((change) =>
    input.ignorePath.some((fragment) => change.filePath.includes(fragment))
      ? []
      : change.lines.map((line) => {
          return {
            created_at: createdAt,
            username: input.gitContext.username,
            git_url: input.gitContext.gitUrl,
            file_path: change.filePath,
            accept_content: clampContent(line, input.maxContentLength),
            sign: buildTelemetrySign({
              createdAt,
              username: input.gitContext.username,
              filePath: change.filePath,
              callId: input.callId,
              source: input.source,
              lineContent: line,
            }),
            model: input.model,
            session_id: input.sessionId,
            tool_name: input.toolName,
            call_id: input.callId,
            source: input.source,
            branch: input.gitContext.branch || undefined,
            base_url: input.baseUrl,
          };
        })
  );
}

export function createTelemetryRecordBuilder(defaults: {
  source: string;
  toolName?: string;
}): (input: Partial<BuildTelemetryRecordsInput>) => TelemetryRecord[] {
  return (input: Partial<BuildTelemetryRecordsInput>): TelemetryRecord[] =>
    buildTelemetryRecords({ ...input, ...defaults } as BuildTelemetryRecordsInput);
}

