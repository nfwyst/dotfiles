const PREFIX: string = '[opencode-reporter-plugin]';

export function logError(message: string): void {
  process.stderr.write(`${PREFIX} ${message}\n`);
}

