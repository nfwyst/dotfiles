import path from 'path';

export function resolveAbsolutePath(baseDirectory: string, filePath: string): string {
  return path.isAbsolute(filePath) ? filePath : path.join(baseDirectory, filePath);
}

